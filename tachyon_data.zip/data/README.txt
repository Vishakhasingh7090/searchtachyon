Data underlying the figures and tables of
'A population-level matched-filter search for tachyonic arrival-time advances
in gamma-ray bursts and their gravitational-wave counterparts' (V. Singh).

Units: energies in eV, times in s, theta = E_t^2 in eV^2 unless a column name says otherwise.

kinematics_vs_energy.csv        Fig. 1  velocity excess and z=1 advance vs observed energy
kernels_I1_I2.csv               Fig. 3  cosmological kernels and their ratio
advance_vs_z_1MeV_1meV.csv      Fig. 4  naive / leading-order / exact advance
advance_by_band_1meV.csv        Fig. 5  advance per observing band
fiducial_catalog_seed42.csv     Sec. 5.1 simulated fiducial catalog (one row per event-band)
fiducial_fit.json               Sec. 5.1 GLS fit of that catalog, information budget
fiducial_bootstrap_theta.csv    Fig. 8a 1000 bootstrap resamples of theta_hat
classifier_auc.csv              Fig. 9  cross-validated AUC per injected scale
scaling_UL_vs_N.csv             Fig. 10 median 95% limit vs catalog size
coverage.csv                    Fig. 11 coverage and pulls vs injected E_t
meanlag_bias.csv                Fig. 12 bias from a systematic spectral lag
jet_delay.csv                   Sec. 6.4 anchored-event jet delay test
heavy_tails.csv                 Fig. 13 Student-t lag test
redshift_error.csv              Fig. 14a redshift-error test
anchored_fraction.csv           Fig. 14b anchored-fraction sweep
liv_confusion.csv               Fig. 15 tachyon / linear-LIV joint fit
gw170817_bound_vs_energy.csv    Fig. 16 single-event bound vs assumed photon energy
results_all.json                every number in the paper, machine-readable

Fiducial simulation settings: 400 events, sigma_lag = 0.5 s (Gaussian), 20% GW-anchored,
log-normal redshifts (median 0.8, log-width 0.7, 0.005 <= z <= 5), Planck 2018 flat LCDM.
Band energies / timing / detection probabilities: MeV 0.5 MeV 10 ms 1.00; GeV 1 GeV 100 ms 0.45;
TeV 1 TeV 0.5 s 0.15; nu 100 TeV 1 s 0.08.
